package com.SimDetails.Exception;

public class SimDetailsException extends RuntimeException {

	private String message;

	public SimDetailsException() {
	}

	public SimDetailsException(String msg) {
		super(msg);
		this.message = msg;
	}
}
