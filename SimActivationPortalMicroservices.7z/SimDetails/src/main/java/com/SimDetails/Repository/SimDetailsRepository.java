package com.SimDetails.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.SimDetails.Entity.SimDetailsEntity;

@Repository
public interface SimDetailsRepository extends JpaRepository<SimDetailsEntity, Integer> {

	public Optional<SimDetailsEntity> findBysimNumberAndServiceNumber(long simNumber, long serviceNumber);

}
