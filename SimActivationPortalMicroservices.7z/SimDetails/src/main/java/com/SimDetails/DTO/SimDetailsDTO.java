package com.SimDetails.DTO;

import org.springframework.beans.factory.annotation.Autowired;

import com.SimDetails.Entity.SimDetailsEntity;

public class SimDetailsDTO {

	private int simId;
	private long serviceNumber;
	private long simNumber;
	private String simStatus;

	@Autowired
	SimDetailsEntity simDetailsEntity;

	public int getSimId() {
		return simId;
	}

	public void setSimId(int simId) {
		this.simId = simId;
	}

	public long getServiceNumber() {
		return serviceNumber;
	}

	public void setServiceNumber(long serviceNumber) {
		this.serviceNumber = serviceNumber;
	}

	public long getSimNumber() {
		return simNumber;
	}

	public void setSimNumber(long simNumber) {
		this.simNumber = simNumber;
	}

	public String getSimStatus() {
		return simStatus;
	}

	public void setSimStatus(String simStatus) {
		this.simStatus = simStatus;
	}

	// DTO to ENTITY
	public SimDetailsEntity convertToEntity(SimDetailsDTO simDetailsDTO) {

		simDetailsEntity.setServiceNumber(this.getServiceNumber());
		simDetailsEntity.setSimId(this.getSimId());
		simDetailsEntity.setSimNumber(this.getSimNumber());
		simDetailsEntity.setSimStatus(this.getSimStatus());

		return simDetailsEntity;

	}

	// Entity to DTO
	public static SimDetailsDTO convertToDTO(SimDetailsEntity simDetailsEntity) {

		SimDetailsDTO simDTO = new SimDetailsDTO();
		simDTO.setServiceNumber(simDetailsEntity.getServiceNumber());
		simDTO.setSimNumber(simDetailsEntity.getSimNumber());
		simDTO.setSimId(simDetailsEntity.getSimId());
		simDTO.setSimStatus(simDetailsEntity.getSimStatus());

		return simDTO;
	}

}
