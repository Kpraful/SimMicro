package com.SimDetails.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.NotNull;

@Entity
public class SimDetailsEntity {

	@Id
	@SequenceGenerator(name = "sim_sequence", allocationSize = 1)
	private int simId;

	@Column(name = "serviceNumber")
//	@ServiceNumber(message="This is from ServiceNumber")
	private long serviceNumber;

//	@SimNumber(message="THIS IS MESSAGE")
	@Column(name = "simNumber")
	private long simNumber;

	@Column(name = "simStatus")
	@NotNull
	private String simStatus;

	public int getSimId() {
		return simId;
	}

	public void setSimId(int simId) {
		this.simId = simId;
	}

	public long getServiceNumber() {
		return serviceNumber;
	}

	public void setServiceNumber(long serviceNumber) {
		this.serviceNumber = serviceNumber;
	}

	public long getSimNumber() {
		return simNumber;
	}

	public void setSimNumber(long simNumber) {
		this.simNumber = simNumber;
	}

	public String getSimStatus() {
		return simStatus;
	}

	public void setSimStatus(String simStatus) {
		this.simStatus = simStatus;
	}

	public SimDetailsEntity() {
		super();
	}

	public SimDetailsEntity(int simId, long serviceNumber, long simNumber, @NotNull String simStatus) {
		super();
		this.simId = simId;
		this.serviceNumber = serviceNumber;
		this.simNumber = simNumber;
		this.simStatus = simStatus;
	}

	@Override
	public String toString() {
		return "SimDetailsEntity [simId=" + simId + ", serviceNumber=" + serviceNumber + ", simNumber=" + simNumber
				+ ", simStatus=" + simStatus + "]";
	}

}
