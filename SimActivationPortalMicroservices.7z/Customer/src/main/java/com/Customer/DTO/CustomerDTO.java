package com.Customer.DTO;

import org.springframework.beans.factory.annotation.Autowired;

import com.Customer.Entity.CustomerEntity;

public class CustomerDTO {

	@Autowired
	CustomerEntity customerEntity;

	private long UniqueIdNumber;
	private String dateOfBirth;
	private String firstName;
	private String lastName;
	private String emailAddress;
	private String idType;
	private int customerAddress_addressId;
	private int simId;

	public long getUniqueIdNumber() {
		return UniqueIdNumber;
	}

	public void setUniqueIdNumber(long uniqueIdNumber) {
		UniqueIdNumber = uniqueIdNumber;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getIdType() {
		return idType;
	}

	public void setIdType(String idType) {
		this.idType = idType;
	}

	public int getCustomerAddress_addressId() {
		return customerAddress_addressId;
	}

	public void setCustomerAddress_addressId(int customerAddress_addressId) {
		this.customerAddress_addressId = customerAddress_addressId;
	}

	public int getSimId() {
		return simId;
	}

	public void setSimId(int simId) {
		this.simId = simId;
	}

	// Convert DTO to Entity

	public CustomerEntity ConvertToEntity(CustomerDTO customerDTO) {

		customerEntity.setSimId(this.getSimId());
		customerEntity.setDateOfBirth(this.getDateOfBirth());
		customerEntity.setEmailAddress(this.getEmailAddress());
		customerEntity.setUniqueIdNumber(this.getUniqueIdNumber());
		customerEntity.setCustomerAddress_addressId(this.getCustomerAddress_addressId());
		customerEntity.setLastName(this.getLastName());
		customerEntity.setIdType(this.getIdType());
		customerEntity.setFirstName(this.getFirstName());
		return customerEntity;

	}

	// Convert to DTO

	public static CustomerDTO ConverToDTO(CustomerEntity customerEntity) {

		CustomerDTO customerDTO = new CustomerDTO();

		customerDTO.setCustomerAddress_addressId(customerEntity.getCustomerAddress_addressId());
		customerDTO.setDateOfBirth(customerEntity.getDateOfBirth());
		customerDTO.setEmailAddress(customerEntity.getEmailAddress());
		customerDTO.setFirstName(customerEntity.getFirstName());
		customerDTO.setIdType(customerEntity.getIdType());
		customerDTO.setLastName(customerEntity.getLastName());
		customerDTO.setSimId(customerEntity.getSimId());
		customerDTO.setUniqueIdNumber(customerEntity.getUniqueIdNumber());

		return customerDTO;
	}

}
