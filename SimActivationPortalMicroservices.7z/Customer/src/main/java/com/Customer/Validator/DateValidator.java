package com.Customer.Validator;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class DateValidator implements ConstraintValidator<com.Customer.Validator.Date, String> {

	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		// TODO Auto-generated method stub
		try {
			String pattern = "yyyy-mm-dd";
			SimpleDateFormat format = new SimpleDateFormat(pattern);
			Date date = format.parse(value);
			return true;
		} catch (Exception e) {
			return false;
		}
	}
}
