package com.CustomerIdentity.Entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Email;

@Entity
public class CustomerIdentityEntity {
	@Id
	private long UniqueIdNumber;
	private String dateOfBirth;
	private String firstName;
	private String lastName;
	@Email
	private String emailAddress;
	private String State;
	public long getUniqueIdNumber() {
		return UniqueIdNumber;
	}
	public void setUniqueIdNumber(long uniqueIdNumber) {
		UniqueIdNumber = uniqueIdNumber;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	
	public CustomerIdentityEntity() {
		super();
	}
	
	public CustomerIdentityEntity(long uniqueIdNumber, String dateOfBirth, String firstName, String lastName,
			@Email String emailAddress, String state) {
		super();
		UniqueIdNumber = uniqueIdNumber;
		this.dateOfBirth = dateOfBirth;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailAddress = emailAddress;
		State = state;
	}
	@Override
	public String toString() {
		return "CustomerIdentityEntity [UniqueIdNumber=" + UniqueIdNumber + ", dateOfBirth=" + dateOfBirth
				+ ", firstName=" + firstName + ", lastName=" + lastName + ", emailAddress=" + emailAddress + ", State="
				+ State + "]";
	}
	
	
}
