package com.CustomerIdentity.Repository;

public class CustomerAddressRepository {

}
