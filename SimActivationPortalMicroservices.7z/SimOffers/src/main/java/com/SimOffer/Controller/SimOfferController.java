package com.SimOffer.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.SimOffer.DTO.SimOfferDTO;
import com.SimOffer.Service.SimOfferService;

@RestController
public class SimOfferController {

	@Autowired
	SimOfferService simOfferService;

	@GetMapping("/SimOffer/{SimId}")
	public SimOfferDTO GetSimOffer(@PathVariable int SimId) {

		return simOfferService.GetSimOffer(SimId);
	}
}
