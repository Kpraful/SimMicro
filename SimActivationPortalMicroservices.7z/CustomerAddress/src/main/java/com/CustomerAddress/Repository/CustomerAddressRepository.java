package com.CustomerAddress.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.CustomerAddress.Entity.CustomerAddressEntity;
import com.CustomerAddress.Service.CustomerAddressService;

@Repository
public interface CustomerAddressRepository extends JpaRepository<CustomerAddressService, Integer> {

	Optional<CustomerAddressEntity> findById(long id);

	Optional<CustomerAddressEntity> save(CustomerAddressEntity customerAddressEntity);
}
