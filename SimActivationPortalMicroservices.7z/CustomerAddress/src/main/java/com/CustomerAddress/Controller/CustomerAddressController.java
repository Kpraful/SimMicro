package com.CustomerAddress.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.CustomerAddress.DTO.CustomerAddressDTO;
import com.CustomerAddress.Service.CustomerAddressService;

@RestController
public class CustomerAddressController {

	@Autowired
	CustomerAddressService customerAddressService;

	@GetMapping("/address/{Id}/{address}/{city}/{pincode}/{customerAddressID}")
	public CustomerAddressDTO updateAddress(@PathVariable(required = false) String address, @PathVariable long Id,
			@PathVariable(required = false) String city, @PathVariable(required = false) long pincode,
			@PathVariable int customerAddressID) {

		return customerAddressService.updateAddress(address, city, Id, pincode, customerAddressID);

	}
}
