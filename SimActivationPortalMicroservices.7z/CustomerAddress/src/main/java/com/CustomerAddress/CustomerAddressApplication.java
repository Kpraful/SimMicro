package com.CustomerAddress;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerAddressApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerAddressApplication.class, args);
	}

}
