package com.CustomerAddress.Service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.CustomerAddress.DTO.CustomerAddressDTO;
import com.CustomerAddress.Entity.CustomerAddressEntity;
import com.CustomerAddress.Repository.CustomerAddressRepository;

@Service
public class CustomerAddressService {

	@Autowired
	CustomerAddressRepository customerAddressRepository;

	public CustomerAddressDTO updateAddress(String address, String city, long id, long pincode, int customerAddressID) {

		Optional<CustomerAddressEntity> customerAddress = customerAddressRepository.findById(customerAddressID);

		CustomerAddressEntity customerAddressEntity = new CustomerAddressEntity();

		customerAddressEntity = customerAddress.get();

		if (address != null) {
			customerAddressEntity.setAddress(address);
		}
		if (city != null) {
			customerAddressEntity.setCity(city);
		}
		if (pincode != 0) {
			customerAddressEntity.setPincode(pincode);
		}

		customerAddressRepository.save(customerAddressEntity);

		return CustomerAddressDTO.convertToDTO(customerAddressEntity);
	}
}
