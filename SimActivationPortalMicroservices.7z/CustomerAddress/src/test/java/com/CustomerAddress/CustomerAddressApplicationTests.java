package com.CustomerAddress;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerAddressApplicationTests {

	@Test
	void contextLoads() {
	}

}
