package com.Customer.DTO;

public class CustomerAddressDTO {

	private int addressId;
	private String address;
	private String city;
	private long pincode;
	private String state;

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public long getPincode() {
		return pincode;
	}

	public void setPincode(long l) {
		this.pincode = l;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	// Service to DTO

//	public static CustomerAddressDTO convertToDTO(CustomerAddressEntity custEntity) {
//
//		CustomerAddressDTO custDTO = new CustomerAddressDTO();
//
//		custDTO.setAddress(custEntity.getAddress());
//		custDTO.setAddressId(custDTO.getAddressId());
//		custDTO.setCity(custEntity.getCity());
//		custDTO.setPincode(custEntity.getPincode());
//		custDTO.setState(custEntity.getState());
//
//		return custDTO;
//	}

}
