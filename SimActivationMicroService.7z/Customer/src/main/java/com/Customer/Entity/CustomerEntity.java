package com.Customer.Entity;

import javax.persistence.Id;
import javax.validation.constraints.Email;

@javax.persistence.Entity
public class CustomerEntity {

	@Id
	private long UniqueIdNumber;
	private String dateOfBirth;
	private String firstName;
	private String lastName;
	@Email
	private String emailAddress;
	private String idType;
	private int customerAddress_addressId;
	private int simId;
	

	
	public long getUniqueIdNumber() {
		return UniqueIdNumber;
	}
	public void setUniqueIdNumber(long uniqueIdNumber) {
		UniqueIdNumber = uniqueIdNumber;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getIdType() {
		return idType;
	}
	public void setIdType(String idType) {
		this.idType = idType;
	}
	
	public int getCustomerAddress_addressId() {
		return customerAddress_addressId;
	}
	public void setCustomerAddress_addressId(int customerAddress_addressId) {
		this.customerAddress_addressId = customerAddress_addressId;
	}
	public int getSimId() {
		return simId;
	}
	public void setSimId(int simId) {
		this.simId = simId;
	}
	@Override
	public String toString() {
		return "Entity [UniqueIdNumber=" + UniqueIdNumber + ", dateOfBirth=" + dateOfBirth + ", emailAddress="
				+ emailAddress + ", firstName=" + firstName + ", lastName=" + lastName + ", idType=" + idType
				+ ", customerAddress_addressId=" + customerAddress_addressId + ", simId=" + simId + "]";
	}

	
}
