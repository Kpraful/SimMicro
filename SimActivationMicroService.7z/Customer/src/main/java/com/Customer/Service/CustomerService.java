package com.Customer.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Customer.Entity.CustomerEntity;
import com.Customer.Repository.CustomerRepository;

@Service
public class CustomerService {

	@Autowired
	private CustomerRepository customerRepository;

	public String ValidateEmailAndDob(String email, String dob) {
		String msg = "";
		String pattern = "yyyy-mm-dd";
		SimpleDateFormat format = new SimpleDateFormat(pattern);
		try {
			Date date = format.parse(dob);
			List<CustomerEntity> list = customerRepository.findByemailAddressAndDateOfBirth(email, dob);
			System.out.println(email + " " + dob);
			if (list.isEmpty()) {
				msg = "No request placed for you.";
			} else {
				msg = "Success!!";
			}
		} catch (Exception e) {
			msg = e.getMessage();
		}
		return msg;
	}

	public String validateFirstAndLastName(String first, String last, String email) {

		String msg = "Default Message";
		List<CustomerEntity> list = customerRepository.findByFirstNameAndLastName(first, last);

		if (list.isEmpty()) {
			msg = "No customer found for the provided details";
		} else {
			for (var e : list) {

				if (e.getEmailAddress().toUpperCase().equals(email.toUpperCase())) {
					msg = "Success!!";
				} else {
					msg = "Invalid email details!!";
				}
			}
		}
		return msg;
	}

	public int checkID(long id) {

		return customerRepository.findById(id).get().getCustomerAddress_addressId();
	}

//
//	public String AddharVerification(long aadhar, String firstName, String lastName, String dob) {
//
//		Optional<CustomerEntity> opt = customerRepository.findById(aadhar);
//
//		String msg = "";
//
//		CustomerEntity customer = opt.get();
//
//		if (!customer.getDateOfBirth().equals(dob)) {
//			msg = "Incorrect date of birth details";
//		}
//		if (customer.getFirstName().toUpperCase().equals(firstName.toUpperCase())
//				&& customer.getLastName().toUpperCase().equals(lastName.toUpperCase())) {
//			msg = "Detail Verified Successfully!!";
////				 customer.getSimId().setSimStatus("active");
//			customerRepository.save(customer);
//		} else {
//			msg = "Invalid details";
//		}
//		return msg;
//	}
}
