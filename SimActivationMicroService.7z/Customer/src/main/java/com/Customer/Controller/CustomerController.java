package com.Customer.Controller;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.Customer.DTO.CustomerAddressDTO;
import com.Customer.Exception.ErrorResponse;
import com.Customer.Service.CustomerService;
import com.Customer.Validator.Date;

@RestController
@Validated
public class CustomerController {

	@Autowired
	CustomerService customerService;

	@PostMapping("Customer")
	public String VerifyEmail(@RequestParam @com.Customer.Validator.Email String Email,
			@RequestParam @Date String DOB) {

		return customerService.ValidateEmailAndDob(Email, DOB);
	}

	@PostMapping("/customer/VerifyEmail")
	public String verifyEmail(@RequestParam @Size(max = 15) String FirstName,
			@RequestParam @Size(max = 15) String LastName, @RequestParam @com.Customer.Validator.Email String Email) {

		return customerService.validateFirstAndLastName(FirstName, LastName, Email);
	}

	@PutMapping("/customer/updateAddress")
	public CustomerAddressDTO updateAddress(@RequestParam long Id,
			@RequestParam(required = false) @Size(max = 25) String address, @RequestParam(required = false) String city,
			@RequestParam(required = false) @Min(000000) @Max(999999) long pincode) {

		int customerAddressId = customerService.checkID(Id);

		RestTemplate template = new RestTemplate();
		return template.getForObject("http://localhost:8182/address/" + Id + "/" + address + "/" + city + "/" + pincode
				+ "/" + customerAddressId, CustomerAddressDTO.class);

	}

	@ExceptionHandler(javax.validation.ConstraintViolationException.class)
	@ResponseStatus(HttpStatus.CONFLICT)
	public ErrorResponse handleSimDetailsException() {

		return new ErrorResponse(HttpStatus.CONFLICT.value(), "Please Enter valid Input");
	}
}
