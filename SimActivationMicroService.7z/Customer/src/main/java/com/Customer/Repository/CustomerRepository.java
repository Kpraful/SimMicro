package com.Customer.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Customer.Entity.CustomerEntity;

@Repository
public interface CustomerRepository extends JpaRepository<CustomerEntity, Long> {

	Optional<CustomerEntity> findByemailAddress(String email);

	List<CustomerEntity> findByemailAddressAndDateOfBirth(String dob, String email);

	List<CustomerEntity> findByFirstNameAndLastName(String first, String last);

//	List<CustomerEntity> findByemail(String string);

}
