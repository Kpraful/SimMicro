package com.CustomerIdentity.DTO;

public class CustomerIdentityDTO {

}
