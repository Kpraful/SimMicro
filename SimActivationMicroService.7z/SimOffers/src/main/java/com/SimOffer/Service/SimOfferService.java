package com.SimOffer.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SimOffer.DTO.SimOfferDTO;
import com.SimOffer.Entity.SimOfferEntity;
import com.SimOffer.Repository.SimOfferRepository;

@Service
public class SimOfferService {

	@Autowired
	SimOfferRepository simOfferRepository;

	public SimOfferDTO GetSimOffer(int SimId) {

		SimOfferEntity simOfferEntity = simOfferRepository.findBySimId(SimId).orElseThrow();

		return SimOfferDTO.convertToDTO(simOfferEntity);
	}

}
