package com.SimDetails.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.SimDetails.DTO.SimDetailsDTO;
import com.SimDetails.DTO.SimOfferDTO;
import com.SimDetails.Exception.ErrorResponse;
import com.SimDetails.Exception.SimDetailsException;
import com.SimDetails.Service.SimDetailsService;

@RestController
@CrossOrigin
public class SimDetailsController {

	@Autowired
	SimDetailsService simDetailsService;

	@PostMapping("/customer/SimDetails/{SimNumber}/{ServiceNumber}")
	public SimOfferDTO ShowOffers(@PathVariable long SimNumber, @PathVariable long ServiceNumber) {

		SimDetailsDTO verifySimAndServiceNumber = simDetailsService.verifySimAndServiceNumber(SimNumber, ServiceNumber);
		RestTemplate template = new RestTemplate();
		return template.getForObject("http://localhost:8185/SimOffer/" + verifySimAndServiceNumber.getSimId(),
				SimOfferDTO.class);
	}

	@ExceptionHandler(value = SimDetailsException.class)
	@ResponseStatus(HttpStatus.CONFLICT)
	public ErrorResponse handleSimDetailsException(SimDetailsException ex) {

		return new ErrorResponse(HttpStatus.CONFLICT.value(), ex.getMessage());
	}

}
