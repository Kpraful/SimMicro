package com.SimDetails.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SimDetails.DTO.SimDetailsDTO;
import com.SimDetails.Entity.SimDetailsEntity;
import com.SimDetails.Exception.SimDetailsException;
import com.SimDetails.Repository.SimDetailsRepository;

@Service
public class SimDetailsService {

	@Autowired
	SimDetailsRepository simDetailsRepository;

	public SimDetailsDTO verifySimAndServiceNumber(long simNumber, long serviceNumber) {

		SimDetailsEntity simDetailsEntity = simDetailsRepository
				.findBysimNumberAndServiceNumber(simNumber, serviceNumber)
				.orElseThrow(() -> new SimDetailsException("No Such Combination of Sim Number " + simNumber + " "
						+ "and Service Number " + serviceNumber + " is Present"));

		return SimDetailsDTO.convertToDTO(simDetailsEntity);
	}
}
