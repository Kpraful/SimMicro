package com.SimDetails;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimDetailsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimDetailsApplication.class, args);
	}

}
