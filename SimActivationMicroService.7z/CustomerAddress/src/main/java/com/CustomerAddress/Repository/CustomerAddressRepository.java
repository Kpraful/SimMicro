package com.CustomerAddress.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.CustomerAddress.Entity.CustomerAddressEntity;

@Repository
public interface CustomerAddressRepository extends JpaRepository<CustomerAddressEntity, Integer> {
////
//
}

////Optional<CustomerAddressEntity> findById(long id);
////
////Optional<CustomerAddressEntity> save(CustomerAddressEntity customerAddressEntity);